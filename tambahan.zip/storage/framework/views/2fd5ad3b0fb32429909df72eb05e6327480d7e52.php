  <?php echo $__env->make('view-admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col">
      <div class="row">
        <div class="col-12 shadow py-2">
          <button class="btn sticky-top" data-toggle="collapse" href="#collapseExample" role="bu tton">
            Menu
          </button>   
          <a class="float-right mt-2" href="/keluar">Keluar</a>
        </div>
        <div class="col-12 content" style="
            background-color: #f1ebeb;">
            <h2 class="mt-3 text-center">Welcome to app</h2>
            <img class="d-block w-100" height="500" src="/images/create.jpg" style=";">
        </div>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html><?php /**PATH C:\Users\user\Desktop\ujicoba\resources\views/view-admin/home.blade.php ENDPATH**/ ?>